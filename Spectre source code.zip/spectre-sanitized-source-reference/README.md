# Spectre sanitized — source/reference bundle

**Important:** this is not the original Spectre source project and is not a directly buildable Gradle project. The provided input was a compiled `.jar`; no original `.java` sources, Gradle files, or full project history were supplied. I won't label bytecode output as real source code.

## Contents

- `resources/`: non-class resources and metadata copied from the sanitized JAR, excluding nested dependency JARs and obsolete signature files.
- `CLASS_INVENTORY.txt`: all root class paths present in the sanitized JAR.
- `bytecode-disassembly/patched-classes/`: readable `javap -p -c -s -constants` disassembly for each application `.class` entry that differs from the supplied original JAR. These are JVM instructions and signatures, not compilable Java source.
- `patch-notes/`: known patch scope and byte-level entry diff.
- `PATCHED_JAR_SHA256.txt`: hash identifying the exact binary used as input.

## Sanitization scope (as documented by the earlier static patch report)

The binary was patched to disable Spectre's custom account/session-token paths, remote add-on loading, outbound webhook sending, Discord IPC/presence, Spotify lyric HTTP fetching, skin-fetching calls, and embedded media/browser startup/download/process-launch paths. ImGui GUI native loading and local configuration/cache handling were retained. The binary patch also modified embedded dependency JAR entries, listed in `INVENTORY.txt`.

The account flow is intentionally nonfunctional. In the sanitized `GameSession` bytecode, `apply(...)` returns immediately, `prepare(...)` returns `null`, and `mojangAuth(...)` returns `null`.

## How to obtain a real source project

To produce a normal source repository that can be rebuilt with Gradle, the upstream author's source repository or a complete source archive is required. This reference bundle alone cannot reproduce the original project. Reconstructing source from all 1,079 compiled classes is a separate reverse-engineering project and will not recover original comments, formatting, or necessarily exact source-level constructs.

## Safety/testing disclaimer

Static patching is not a guarantee of being malware-free. The JAR was not launched by this process. Re-scan the exact binary with Ratscanner and inspect any remaining HIGH/MEDIUM findings individually.
