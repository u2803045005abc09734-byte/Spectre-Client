# Sanitization notes

The exact input binary and hash are recorded in `../PATCHED_JAR_SHA256.txt`.

Classes changed in the application packages (bytecode dumps are included under `../bytecode-disassembly/patched-classes/` where applicable):

- `net/spectre/client/account/Accounts.class`
- `net/spectre/client/account/AuthHttp.class`
- `net/spectre/client/account/GameSession.class`
- `net/spectre/client/account/MicrosoftLogin.class`
- `net/spectre/client/account/SessionLogin.class`
- `net/spectre/client/addon/AddonManager.class`
- `net/spectre/client/addon/SpectreAddon.class` and `SpectreAddon$GithubRepo.class`
- `net/spectre/client/discord/DiscordIpc.class`
- `net/spectre/client/gui/mainmenu/ConnectionsPanel.class`
- `net/spectre/client/media/MediaPlayer.class`, `MediaRuntime.class`, `MediaScreen.class`, `VideoBrowser.class`
- `net/spectre/client/module/impl/client/SpotifyHudModule.class`
- `net/spectre/client/module/impl/misc/DiscordPresenceModule.class` and `SkinChangeModule.class`
- `net/spectre/client/util/spotify/LyricsService.class`
- `net/spectre/client/webhook/WebhookConfig.class`, `WebhookService.class`

The earlier binary patch comparison reported 28 changed entries in total, including the 8 embedded dependency JARs listed in `../INVENTORY.txt`. This list describes binary changes and is not a source-level patch that can be applied to the upstream project.
