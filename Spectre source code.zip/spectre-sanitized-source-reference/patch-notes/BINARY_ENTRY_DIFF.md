# Binary entry diff against supplied original JAR

Original: spectre-0.9.0+mc26.2.jar
Sanitized: spectre-0.9.0+mc26.2-sanitized.jar
Changed entries: 28
Added entries: 0
Removed entries: 0

## Changed entries
- `META-INF/jars/imgui-java-binding-1.90.0.jar`
- `META-INF/jars/imgui-java-lwjgl3-1.90.0.jar`
- `META-INF/jars/imgui-java-natives-linux-1.90.0.jar`
- `META-INF/jars/imgui-java-natives-macos-1.90.0.jar`
- `META-INF/jars/imgui-java-natives-windows-1.90.0.jar`
- `META-INF/jars/mcef-modern-0.3.3+mc26.2.jcef146.0.10.jar`
- `META-INF/jars/netty-codec-socks-4.2.15.Final.jar`
- `META-INF/jars/netty-handler-proxy-4.2.15.Final.jar`
- `net/spectre/client/account/Accounts.class`
- `net/spectre/client/account/AuthHttp.class`
- `net/spectre/client/account/GameSession.class`
- `net/spectre/client/account/MicrosoftLogin.class`
- `net/spectre/client/account/SessionLogin.class`
- `net/spectre/client/addon/AddonManager.class`
- `net/spectre/client/addon/SpectreAddon$GithubRepo.class`
- `net/spectre/client/addon/SpectreAddon.class`
- `net/spectre/client/discord/DiscordIpc.class`
- `net/spectre/client/gui/mainmenu/ConnectionsPanel.class`
- `net/spectre/client/media/MediaPlayer.class`
- `net/spectre/client/media/MediaRuntime.class`
- `net/spectre/client/media/MediaScreen.class`
- `net/spectre/client/media/VideoBrowser.class`
- `net/spectre/client/module/impl/client/SpotifyHudModule.class`
- `net/spectre/client/module/impl/misc/DiscordPresenceModule.class`
- `net/spectre/client/module/impl/misc/SkinChangeModule.class`
- `net/spectre/client/util/spotify/LyricsService.class`
- `net/spectre/client/webhook/WebhookConfig.class`
- `net/spectre/client/webhook/WebhookService.class`

## Added entries
- None

## Removed entries
- None
